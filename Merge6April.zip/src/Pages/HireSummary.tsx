import React from "react";
import HireSummary from "../Components/HireSummary/HireSummary";

function Summary() {
  return <HireSummary />;
}

export default Summary;
